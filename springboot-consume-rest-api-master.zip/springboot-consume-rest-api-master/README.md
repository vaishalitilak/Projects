    This project describes how to consume restful web service in spring boot.
    Currently covers GET and POST request only.