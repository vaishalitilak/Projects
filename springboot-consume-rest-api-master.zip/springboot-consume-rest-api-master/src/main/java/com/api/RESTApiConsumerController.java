package com.api;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Date;

@RestController(value = "/")
public class RESTApiConsumerController {

    // values are fetched from application.properties file, as it can be any external cum remote machine port
    @Value("${server.port}")
    private
    String PORT;

    // values are fetched from application.properties file, as it can be any external cum remote machine IP or domain name
    @Value("${remoteServerIP}")
    private String REMOTESERVER;

    /**
     * GET API consumer, currently for demo purpose we are consuming API of same application instead of remote application
     */
    @GetMapping(value = "/consumeGetApi")
    private Object consumeGetApi() {

        RestTemplate restTemplate = new RestTemplate();
        Object responseObject = restTemplate.getForObject("http://" + REMOTESERVER + ":" + PORT + "/get", String.class);
        System.out.println("Consumed data from GET API - " + responseObject);

        return responseObject;
    }

    /**
     * POST API consumer, currently for demo purpose we are consuming API of same application instead of remote application
     */
    @GetMapping(value = "/consumePostApi")
    private Object consumePostApi() {

        RestTemplate restTemplate = new RestTemplate();
        Object responseObject = restTemplate.postForObject("http://" + REMOTESERVER + ":" + PORT + "post", "World", String.class);
        System.out.println("Consumed data from POST API - " + responseObject);

        return responseObject;
    }

    /**
     * below call is consumed by {@link #consumeGetApi()}, this call can be called from remote application
     */
    @GetMapping(value = "/get")
    public String get() {
        System.out.println("request on - " + (new Date()));
        return "success";
    }

    /**
     * below call is consumed by {@link #consumePostApi()}, this call can be called from remote application
     */
    @PostMapping(value = "/post")
    public String post(@RequestBody String s) {
        System.out.println("request on - " + (new Date()));
        s = "Hello " + s;
        return s;
    }

}
