import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './product-list.component';
import { ProductDetail } from './product-detail.component';
import { CustomePipe } from '../shared/customepipes';
import { startComp } from '../shared/start.componemt';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ProdService } from './product.service';
import { ProductGaurd } from './product-gaurd.service,';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild([
      {path: 'products', component: ProductListComponent},
      {path: 'products/:id' ,
      canActivate:[ProductGaurd], component:ProductDetail},
    ])
  ],
  declarations: [
     ProductListComponent,
    ProductDetail,
    CustomePipe,
    startComp

  ],
  providers:[
    ProdService,
    ProductGaurd
  ]
})
export class ProductModule { }
