import { Component } from "@angular/core";
import { IProduct } from "./product";
import { OnInit } from "@angular/core/src/metadata/lifecycle_hooks";
import { ProdService } from "./product.service";

@Component({
    templateUrl:'./product-list.component.html',
    styleUrls:['./product-list.component.css']
})

export class ProductListComponent implements OnInit{
    pageTitle: string ='Product List';
    imgWidth: number=50;
    imgMargin: number=2;
    showImg: boolean= false;
    listFilter:string= 'cart';
    product: IProduct[] =[ ];
    errorMessage :string;
    constructor(private _prodService : ProdService){
        
    }
    onRatingClicked(message: string): void{
        this.pageTitle = 'Product List' + message;
    }

    toggleImg():void{
        this.showImg= !this.showImg;
    }
    ngOnInit(): void{
        this._prodService.getProducts()
        .subscribe(product => this.product  =  product,
        error => this.errorMessage= <any>error);
         
    }
}   
